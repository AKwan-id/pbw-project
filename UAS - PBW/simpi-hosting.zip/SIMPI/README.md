# SIMPI - Sistem Informasi Monitoring Proyek Infrastruktur

SIMPI adalah aplikasi web berbasis PHP dan MySQL untuk monitoring proyek infrastruktur, pengelolaan user, anggaran, progres lapangan, penguncian laporan, arsip akun, dan cetak laporan proyek.

Aplikasi ini memakai tema visual profesional dengan warna biru tua, putih, abu netral, dan aksen emas. Tidak menggunakan logo resmi instansi.

## Fitur Utama

- Aktivasi administrator pertama.
- Login dan logout dengan session timeout.
- Manajemen user berbasis email kantor personal.
- Data User dipisah menjadi User Aktif, Belum Aktif, dan Arsip / Nonaktif.
- Detail Akun bersifat baca-saja.
- Nama, username, email, dan role akun dikunci setelah akun dibuat.
- Aktivasi akun melalui email dengan token sekali pakai.
- Lupa password melalui email dengan token sekali pakai.
- Admin aktif maksimal 8 orang.
- Admin aktif dapat menonaktifkan admin lain, kecuali dirinya sendiri dan admin terakhir.
- Petugas resign dapat langsung dinonaktifkan oleh admin.
- User aktif tidak dihapus permanen, tetapi dinonaktifkan dan masuk arsip.
- User belum aktif dapat dibatalkan sehingga username dan email dapat dipakai ulang.
- User nonaktif tidak bisa login dan tidak bisa memakai fitur lupa password.
- Admin tidak dapat melihat password, link aktivasi, atau mengambil alih akun pengguna.
- CRUD data proyek.
- Anggaran awal dikunci setelah proyek dibuat.
- Perubahan anggaran dicatat sebagai revisi anggaran dengan nilai lama, nilai baru, alasan, waktu, dan admin yang mengubah.
- CRUD laporan progres oleh pemilik laporan.
- Laporan progres dapat dikunci oleh pemilik laporan.
- User lain dan admin tidak dapat mengedit, menghapus, atau membuka kunci laporan progres milik petugas.
- Perubahan progres dicatat sebagai revisi progres dengan nilai lama, nilai baru, alasan, waktu, dan petugas yang mengubah.
- Persentase progres hanya menerima angka bulat 0 sampai 100.
- Cetak laporan proyek melalui browser, termasuk anggaran awal, anggaran saat ini, revisi anggaran, progres, dan revisi progres.
- Log login, log email, log reset password, dan log status user.

## Struktur Database

Database: `simpi`

Tabel utama:

- `user`
- `proyek`
- `progres`
- `anggaran_revisi`
- `progres_revisi`
- `password_reset_log`
- `password_reset_token`
- `email_log`
- `login_log`
- `user_status_log`

## Instalasi Lokal XAMPP

1. Copy folder `SIMPI` ke `C:\xampp\htdocs\SIMPI`.
2. Jalankan Apache dan MySQL di XAMPP.
3. Import `database.sql` ke MySQL.
4. Buka `http://localhost/SIMPI`.
5. Aktivasi administrator pertama.
6. Konfigurasi SMTP pada `config/email.php` agar aktivasi akun dan lupa password via email berjalan.

## Konfigurasi Database Lokal

File koneksi berada di:

`config/koneksi.php`

Default XAMPP:

```php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'simpi';
```

## Konfigurasi Email

File konfigurasi email berada di:

`config/email.php`

Gunakan SMTP valid dari hosting atau penyedia email agar aktivasi user dan reset password dapat terkirim.

## Aturan Akun

- Satu akun hanya digunakan oleh satu orang.
- Satu admin memakai satu email kantor personal.
- Satu petugas memakai satu email kantor personal.
- Email umum kantor hanya digunakan sebagai email pengirim sistem, bukan akun login bersama.
- Akun aktif yang tidak lagi bertugas dinonaktifkan dan masuk arsip.
- Akun belum aktif yang salah input dapat dibatalkan.
- Admin tidak dapat mengubah identitas, password, atau laporan milik petugas.

## Catatan Keamanan

- Jangan upload password SMTP asli ke repository publik.
- Jangan upload password database hosting asli ke repository publik.
- Anggaran tidak ditimpa langsung; gunakan Revisi Anggaran.
- Progress tidak diubah tanpa jejak; setiap edit menyimpan riwayat revisi.
- Akun nonaktif tidak bisa login dan tidak bisa meminta link reset password.
