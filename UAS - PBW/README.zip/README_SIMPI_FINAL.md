# SIMPI - Sistem Informasi Monitoring Proyek Infrastruktur

SIMPI adalah aplikasi web berbasis PHP dan MySQL untuk monitoring proyek infrastruktur. Aplikasi ini mendukung autentikasi user, pembagian role, pengelolaan data proyek, pelaporan progres lapangan, riwayat revisi, penguncian laporan, arsip akun, dan cetak laporan proyek melalui browser.

Project ini dibuat untuk UAS mata kuliah Pemrograman Berbasis Web.

## Project Links

| Kebutuhan | Link |
|---|---|
| Repository GitHub | https://github.com/AKwan-id/pbw-project/tree/main/UAS%20-%20PBW |
| Live Application | https://simpi-project.freedev.app |
| YouTube Presentation | Diisi setelah video selesai |

> Catatan: jangan mempublikasikan kredensial akun asli di README publik. Jika evaluator membutuhkan akun demo, gunakan akun uji khusus dan bagikan melalui kanal pengumpulan yang aman.

## Main Features

- Aktivasi administrator pertama saat database belum memiliki user.
- Login dan logout dengan session.
- Session timeout.
- Role-based access control untuk `admin` dan `petugas`.
- Manajemen user berbasis status akun.
- Status user: `belum_aktif`, `aktif`, dan `arsip`.
- Aktivasi user melalui token email.
- Reset password melalui token email.
- Batas admin aktif maksimal 8 orang.
- Pencegahan penonaktifan akun sendiri dan admin terakhir.
- User nonaktif tidak dapat login dan tidak dapat menggunakan fitur reset password.
- Pengelolaan data proyek.
- Pengelolaan laporan progres proyek.
- Penguncian laporan progres oleh pemilik laporan.
- Riwayat revisi anggaran proyek.
- Riwayat revisi progres proyek.
- Cetak laporan proyek melalui browser.
- Log aktivitas login, email, reset password, dan status user.
- Validasi progres dalam rentang 0 sampai 100.
- Konfirmasi JavaScript untuk aksi penting seperti logout, hapus data, aktivasi, dan penonaktifan akun.

## User Roles and Access Control

SIMPI memiliki dua jenis user.

### Admin

Admin memiliki hak akses untuk:

- login dan logout;
- melihat dashboard;
- mengelola data user;
- menambah user baru;
- melihat detail user;
- mengirim aktivasi user;
- menonaktifkan atau membatalkan user sesuai status akun;
- mengelola data proyek;
- merevisi anggaran proyek;
- melihat laporan progres;
- mencetak laporan proyek.

### Petugas

Petugas memiliki hak akses untuk:

- login dan logout;
- melihat dashboard;
- melihat data proyek;
- membuat laporan progres proyek;
- mengedit laporan progres miliknya sendiri selama belum terkunci;
- menghapus laporan progres miliknya sendiri selama belum terkunci;
- mengunci atau membuka kunci laporan progres miliknya sendiri.

## UAS Requirement Mapping

| Ketentuan Soal | Implementasi pada SIMPI |
|---|---|
| Aplikasi berbasis web bertema bebas | SIMPI memakai tema monitoring proyek infrastruktur. |
| Minimal memiliki 2 tabel | Database memiliki tabel `user`, `proyek`, `progres`, dan beberapa tabel pendukung. |
| Harus memiliki tabel user | Tersedia tabel `user`. |
| Login dan logout untuk user | Tersedia `login.php` dan `logout.php`. |
| CRUD untuk tabel | CRUD utama tersedia untuk `proyek` dan `progres`. Tabel `user` dikelola dengan lifecycle terbatas karena berhubungan dengan autentikasi dan hak akses. |
| Form input dan edit | Form input dan edit tersedia pada `proyek` dan `progres`. Pada `user`, aplikasi memakai tambah user, detail user, aktivasi, nonaktif, dan arsip, bukan edit bebas. |
| Tabel untuk menampilkan data | Tersedia halaman data user, data proyek, dan data progres. |
| Link edit dan delete | Tersedia pada modul `proyek` dan `progres`. Modul `user` memakai aksi detail, aktivasi, nonaktif, batalkan, dan arsip. |
| Menu untuk berpindah halaman | Tersedia navbar dengan menu Dashboard, Data User, Data Proyek, Data Progres, Akun, dan Logout. Menu Data User hanya tampil untuk admin. |
| CSS untuk mempercantik halaman | Menggunakan Bootstrap 5.3.3 dan `assets/css/style.css`. |
| Tambahan nilai JavaScript/JQuery | Menggunakan JavaScript pada `assets/js/script.js`. |
| Source code di Git public | Source code tersedia melalui repository GitHub public. |
| Tidak mengupload ZIP sebagai pengumpulan utama | Pengumpulan utama menggunakan link repository GitHub. |
| Presentasi YouTube 7 menit | Link video diisi setelah video selesai. |
| Tambahan nilai hosting cloud | Aplikasi tersedia melalui live application link. |

## Security Design for User Management

Tabel `user` digunakan untuk autentikasi, status akun, dan pembagian hak akses antara admin dan petugas. Karena itu, data user tidak dibuat sebagai edit bebas seperti data proyek atau progres.

Pengelolaan user difokuskan pada:

- tambah user;
- tampil data user;
- detail user;
- kirim aktivasi;
- aktivasi akun;
- reset password;
- nonaktifkan akun;
- batalkan akun belum aktif;
- arsip akun.

Keputusan ini dibuat untuk mengurangi risiko perubahan data akun secara sembarangan, menjaga integritas role `admin` dan `petugas`, serta menjaga konsistensi riwayat login dan status user. Perubahan sensitif seperti password tidak dilakukan melalui edit manual di tabel user, tetapi melalui mekanisme aktivasi dan reset password.

## Tech Stack

- PHP native.
- MySQL / MariaDB compatible database.
- HTML.
- CSS.
- JavaScript.
- Bootstrap 5.3.3 via CDN.
- XAMPP or compatible Apache, PHP, and MySQL environment for local development.

## Project Structure

```text
SIMPI/
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
├── config/
│   ├── email.php
│   └── koneksi.php
├── includes/
│   ├── auth.php
│   ├── footer.php
│   ├── functions.php
│   ├── header.php
│   ├── mailer.php
│   └── navbar.php
├── progres/
│   ├── edit.php
│   ├── hapus.php
│   ├── index.php
│   ├── kunci.php
│   └── tambah.php
├── proyek/
│   ├── cetak.php
│   ├── detail.php
│   ├── edit.php
│   ├── hapus.php
│   ├── index.php
│   ├── revisi_anggaran.php
│   └── tambah.php
├── user/
│   ├── detail.php
│   ├── edit.php
│   ├── hapus.php
│   ├── index.php
│   ├── kirim_aktivasi.php
│   └── tambah.php
├── aktivasi.php
├── dashboard.php
├── database.sql
├── forgot_password.php
├── ganti_password.php
├── index.php
├── login.php
├── logout.php
└── reset_password.php
```

## Database Schema

Database name: `simpi`

### Main Tables

| Table | Purpose |
|---|---|
| `user` | Menyimpan data akun, role, status akun, dan informasi autentikasi. |
| `proyek` | Menyimpan data proyek infrastruktur. |
| `progres` | Menyimpan laporan progres proyek yang dibuat oleh user. |

### Supporting Tables

| Table | Purpose |
|---|---|
| `anggaran_revisi` | Menyimpan riwayat revisi anggaran proyek. |
| `progres_revisi` | Menyimpan riwayat revisi laporan progres. |
| `password_reset_log` | Menyimpan log permintaan aktivasi dan reset password. |
| `password_reset_token` | Menyimpan token aktivasi dan reset password dalam bentuk hash. |
| `email_log` | Menyimpan status pengiriman email sistem. |
| `login_log` | Menyimpan riwayat login user. |
| `user_status_log` | Menyimpan riwayat perubahan status user. |

## Local Installation

1. Clone repository atau download source code dari GitHub.
2. Copy folder `SIMPI` ke direktori `htdocs` XAMPP.
3. Jalankan Apache dan MySQL melalui XAMPP.
4. Buat database MySQL bernama `simpi`.
5. Import file `database.sql` ke database `simpi`.
6. Periksa konfigurasi database di `config/koneksi.php`.
7. Buka aplikasi melalui browser:

```text
http://localhost/SIMPI
```

8. Jika database belum memiliki user, aplikasi akan mengarahkan ke halaman aktivasi administrator pertama.
9. Buat akun administrator pertama.
10. Login menggunakan akun administrator yang baru dibuat.

## Database Configuration

File koneksi database berada di:

```text
config/koneksi.php
```

Default konfigurasi lokal XAMPP:

```php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'simpi';
```

Untuk deployment publik, ganti nilai tersebut sesuai kredensial database hosting.

## Email Configuration

File konfigurasi email berada di:

```text
config/email.php
```

Konfigurasi default:

```php
define('MAIL_DRIVER', 'mail');
define('MAIL_FROM_ADDRESS', 'noreply@simpi.local');
define('MAIL_FROM_NAME', 'SIMPI');

define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_ENCRYPTION', 'tls');
```

Jika menggunakan SMTP, isi `SMTP_HOST`, `SMTP_USERNAME`, `SMTP_PASSWORD`, dan pengaturan terkait sesuai layanan email yang digunakan. Jangan commit password SMTP asli ke repository public.

## Application Flow

1. Administrator pertama dibuat melalui halaman aktivasi awal.
2. Admin login ke sistem.
3. Admin menambahkan user baru dengan role `admin` atau `petugas`.
4. User baru melakukan aktivasi akun melalui token email.
5. Admin mengelola data proyek.
6. Petugas membuat laporan progres proyek.
7. Petugas dapat mengedit atau menghapus laporan miliknya sendiri selama belum terkunci.
8. Riwayat perubahan progres dan anggaran disimpan ke tabel revisi.
9. Laporan proyek dapat dicetak melalui browser.
10. User logout setelah selesai menggunakan aplikasi.

## Manual Testing Checklist

### Authentication

- [ ] Administrator pertama dapat dibuat saat database masih kosong.
- [ ] User dapat login dengan akun aktif.
- [ ] User nonaktif tidak dapat login.
- [ ] User dapat logout.
- [ ] Session timeout berjalan sesuai konfigurasi.

### Admin

- [ ] Admin dapat membuka dashboard.
- [ ] Admin dapat membuka Data User.
- [ ] Admin dapat menambah user.
- [ ] Admin dapat melihat detail user.
- [ ] Admin dapat mengirim aktivasi user.
- [ ] Admin dapat menonaktifkan atau membatalkan user sesuai status akun.
- [ ] Admin dapat mengelola data proyek.
- [ ] Admin dapat merevisi anggaran proyek.
- [ ] Admin dapat melihat data progres.
- [ ] Admin dapat mencetak laporan proyek.

### Petugas

- [ ] Petugas dapat login.
- [ ] Petugas tidak dapat membuka halaman khusus admin.
- [ ] Petugas dapat melihat data proyek.
- [ ] Petugas dapat menambah progres.
- [ ] Petugas dapat mengedit progres miliknya sendiri selama belum terkunci.
- [ ] Petugas dapat menghapus progres miliknya sendiri selama belum terkunci.
- [ ] Petugas dapat mengunci atau membuka kunci progres miliknya sendiri.

### UI and Client-Side Behavior

- [ ] Navbar dapat digunakan untuk berpindah halaman.
- [ ] CSS tampil dengan benar.
- [ ] Bootstrap CDN dapat dimuat.
- [ ] JavaScript konfirmasi aksi berjalan.
- [ ] Validasi persentase progres berjalan di sisi client.

## Deployment Checklist

Sebelum aplikasi dipublikasikan, lakukan pemeriksaan berikut:

- [ ] Pastikan repository tidak menyimpan password database hosting asli.
- [ ] Pastikan repository tidak menyimpan password SMTP asli.
- [ ] Gunakan kredensial database khusus untuk hosting.
- [ ] Gunakan HTTPS pada domain live application.
- [ ] Pastikan konfigurasi database hosting sudah sesuai.
- [ ] Pastikan konfigurasi email sudah sesuai jika fitur email digunakan.
- [ ] Gunakan akun demo khusus jika evaluator memerlukan akses login.
- [ ] Jangan membagikan akun admin asli di README publik.
- [ ] Uji login, logout, tambah, edit, hapus, dan cetak laporan pada environment online.

## Presentation Checklist

Video presentasi mengikuti ketentuan UAS:

- Total durasi: 7 menit.
- Demo aplikasi: 2 menit.
- Penjelasan kode: 5 menit.
- Video di-upload ke YouTube.
- Link YouTube dikumpulkan bersama link GitHub.
- Jika aplikasi sudah di-hosting, link aplikasi online juga dikumpulkan.

## Suggested Video Structure

```text
00:00 - 00:15  Opening dan pengenalan SIMPI
00:15 - 02:00  Demo aplikasi online
02:00 - 02:40  Struktur folder project
02:40 - 03:20  Struktur database
03:20 - 04:00  Login, logout, session, dan role
04:00 - 04:50  CRUD proyek
04:50 - 05:40  CRUD progres
05:40 - 06:20  Manajemen user dan alasan pembatasan edit user
06:20 - 06:50  CSS dan JavaScript
06:50 - 07:00  Closing dan link pengumpulan
```

## Public Repository Notes

- File `database.sql` disertakan untuk instalasi database.
- File konfigurasi masih perlu disesuaikan untuk environment hosting.
- Password produksi, password database hosting, dan password SMTP tidak boleh dipublikasikan.
- Tidak ada kredensial akun demo yang dipublikasikan di README ini.

## License

Lisensi belum ditentukan.
